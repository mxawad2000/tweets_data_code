/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui_beans;

/**
 *
 * @author Mamoun.Awad
 */
import util.TweetDetails;
import java.util.*;
public class TweetsPager {
    private int PageSize = 10;
    private int CurrPage = 0;
    private StatRecord sRecord = new StatRecord();
    private DailyStatRecord dsRecord = new DailyStatRecord();
    
    private List<TweetDetails> lst = new ArrayList<>();
    public TweetsPager(int PageSize){ this.PageSize = PageSize;}
    public TweetsPager(List lst, int PageSize){
        this.lst.addAll(lst);
        System.out.println("TweetPager corp:" + this.lst.get(0).getCorp());
        this.PageSize = PageSize;
        initStat(this.lst);
    }
    private void initStat(List<TweetDetails> lst){
        for(TweetDetails t : lst){
            sRecord.Add(t.gethSentiment());
            dsRecord.Add(t.getTweetObj().getTwDate(), t.gethSentiment());
        }
    }
    public void resetTweets(List lst){
        this.lst.clear();
        lst.addAll(lst);
        initStat(lst);
        this.CurrPage = 0;
    }
    public void setPageSize(int PageSize){
        this.PageSize = PageSize;
        this.CurrPage = 0; 
    }
    public boolean IsFirstPage(){ return this.CurrPage == 1;}
    public boolean isLastPage(){ return this.CurrPage == this.GetNumPages();}
    public List<TweetDetails> GetNextPage(){
        //check if I am at last page.
        int N = GetNumPages();        
        if(this.CurrPage == N) return new ArrayList<>();
        else {
            int from = this.CurrPage * this.PageSize;
            this.CurrPage++;
            int toPage = Math.min( lst.size(), from + this.PageSize );
            return this.lst.subList(from, toPage);                        
        }
    }
    public void resetPage(){this.CurrPage = 0;}
    public List<TweetDetails> GetPrevPage(){
        //check if I am at first page.
        if(this.CurrPage <= 1) return new ArrayList<>();
        else {
            this.CurrPage--;
            int from = this.CurrPage * this.PageSize;
            int toPage = Math.min( lst.size(), from + this.PageSize );
            return this.lst.subList(from, toPage);                        
        }
    }
    public int GetNumPages(){
        int N = this.lst.size() / this.PageSize;
        if(this.lst.size() % this.PageSize != 0) N++;
        return N;
    }
    public int GetCurrentPage(){ return this.CurrPage;}
    public List<TweetDetails> getTweets(){ return this.lst;}
    public StatRecord getStatRecord(){ return this.sRecord;}
    public DailyStatRecord getDailyStatRecord(){ return this.dsRecord;}
}

