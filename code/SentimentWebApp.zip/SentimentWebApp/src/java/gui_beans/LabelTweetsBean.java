/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui_beans;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import managers.SessionManager;
import managers.TweetCacheManager;
import managers.TwitterSentimentManager;
import managers.TwitterT;

/**
 *
 * @author Mamoun.Awad
 */
public class LabelTweetsBean {

    static TwitterSentimentManager twitterSentimentManager = lookupTwitterSentimentManagerBean();    
    public static final String TWEET_EXPORT_TAG = "tweets_export_tag";    
        
    public static void handleSubmitLabelsUncached(HttpServletRequest req, HttpSession session){
        String userId = managers.SessionManager.getCurrentUser(session).getUserId();
        String[] tweets = req.getParameterValues("tweet_id");
        String[] h_codes = req.getParameterValues("h_sent");
        String corp = req.getParameter("corp");
        for(int i=0;i<h_codes.length;i++){
            System.out.printf("tweet:%s, code:%s, corp:%s\n", tweets[i], 
                    h_codes[i],corp);            
        }
        lookupTwitterSentimentManagerBean().persistOrUpdateSentiment(tweets, h_codes, corp, userId);
    }
    public static void handleSubmitLabels(HttpServletRequest req, HttpSession session){
        String userId = managers.SessionManager.getCurrentUser(session).getUserId();
        String[] tweets = req.getParameterValues("tweet_id");
        String[] h_codes = req.getParameterValues("h_sent");
        String corp = req.getParameter("corp");
        for(int i=0;i<h_codes.length;i++){
            System.out.printf("tweet:%s, code:%s, corp:%s\n", tweets[i], 
                    h_codes[i],corp);            
        }
        lookupTwitterSentimentManagerBean().persistOrUpdateSentiment(tweets, h_codes, corp, userId);
        String user = SessionManager.getCurrentUser(session).getUserId();
        //remove labeled tweets from the list...
        String key ="tweets-"+user+"-" + corp;
        List<util.TweetDetails> lst = (List<util.TweetDetails>)session.getAttribute(key);
        for(String tw : tweets){            
            for(int i=0;i<lst.size();i++){
                if(lst.get(i).getTweetObj().getTweetId().equals(tw)){
                    lst.remove(i);
                    break;
                }
            }
        }
        System.out.println("Size of session list of " + corp + "-"+ user + " :" + lst.size());
    }
    public static List<util.TweetDetails> getNextTweetsUnCached(HttpSession session, 
        String corp, String fromDate, String toDate,String kw){        
        String user = SessionManager.getCurrentUser(session).getUserId();
        List<util.TweetDetails> lst = TweetCacheManager.GetInstance().
                getUnLabeledTweets(corp, user,fromDate,toDate,kw);        
        return lst;
    }
    public static List<util.TweetDetails> getNextTweets(HttpSession session, String corp){        
        String user = SessionManager.getCurrentUser(session).getUserId();
        String key ="tweets-"+user+"-" + corp;
        List<util.TweetDetails> lst = (List<util.TweetDetails>)session.getAttribute(key);
        if(lst == null || lst.isEmpty()){
            System.out.println("New List is retrieved.........................");
            lst = TweetCacheManager.GetInstance().getUnLabeledTweets(corp, user);
            session.setAttribute(key, lst);
        }
        if(lst.size() > 10)
            return lst.subList(0, 10);
        else 
            return lst.subList(0,lst.size());
    }

    private static TwitterSentimentManager lookupTwitterSentimentManagerBean() {
        try {
            Context c = new InitialContext();
            return (TwitterSentimentManager) c.lookup("java:global/SentimentWebApp/TwitterSentimentManager!managers.TwitterSentimentManager");
        } catch (NamingException ne) {
            Logger.getLogger(LabelTweetsBean.class.getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }
    ////////////////////////////////////////////////////////////////////////////
    public static List<util.TweetDetails> getNextLabeledTweets(int Page, String corp){        
        
        return LabelTweetsBean.lookupTwitterSentimentManagerBean().GetLabeledTweets(Page, corp);
    }
    public static List<util.TweetDetails> getNextLabeledTweets(String corp, HttpSession session){
        TweetsPager obj = (TweetsPager) session.getAttribute("tweetsPager-" +  corp);
        Integer pageSize = (Integer) session.getAttribute("tweetsPager-pageSize");
        if(pageSize == null) pageSize = 10;
        if( obj == null){
            obj = new TweetsPager( 
                    LabelTweetsBean.lookupTwitterSentimentManagerBean().GetLabeledTweets(corp),
                    pageSize);            
            session.setAttribute("tweetsPager-" +  corp,obj);
        }
        return obj.GetNextPage();        
    }
    
     public static TweetsPager getPager(String corp, HttpSession session){
         TweetsPager obj = (TweetsPager) session.getAttribute("tweetsPager-" +  corp);
         if(obj == null){
            Integer pageSize = (Integer) session.getAttribute("tweetsPager-pageSize");
            if(pageSize == null) pageSize = 10;
            obj = new TweetsPager( 
                LabelTweetsBean.lookupTwitterSentimentManagerBean().GetLabeledTweets(corp),
                pageSize);            
            session.setAttribute("tweetsPager-" +  corp,obj);
         }
         return obj;
     }
     public static TweetsPager setPager(String corp, HttpSession session){         
        Integer pageSize = (Integer) session.getAttribute("tweetsPager-pageSize");
        if(pageSize == null) pageSize = 10;
        TweetsPager obj = new TweetsPager( 
                LabelTweetsBean.lookupTwitterSentimentManagerBean().GetLabeledTweets(corp),
                pageSize);            
        session.setAttribute("tweetsPager-" +  corp,obj);
        return obj;
     }
}
