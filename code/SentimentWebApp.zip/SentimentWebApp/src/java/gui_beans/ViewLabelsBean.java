/**
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui_beans;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import managers.AccountManager;
import managers.SessionManager;
import managers.TweetCacheManager;
import managers.TwitterSentimentManager;
import managers.TwitterT;

/**
 *
 * @author Mamoun.Awad
 */
public class ViewLabelsBean {

    static TwitterSentimentManager twitterSentimentManager = lookupTwitterSentimentManagerBean();
    public static final String TWEET_EXPORT_TAG = "tweets_export_tag";
            
    public static List<util.TweetDetails> getNextTweets(HttpSession session, String corp){        
        String user = SessionManager.getCurrentUser(session).getUserId();
        String key ="tweets-"+user+"-" + corp;
        List<util.TweetDetails> lst = (List<util.TweetDetails>)session.getAttribute(key);
        if(lst == null || lst.isEmpty()){
            System.out.println("New List is retrieved.........................");
            lst = TweetCacheManager.GetInstance().getUnLabeledTweets(corp, user);
            session.setAttribute(key, lst);
        }
        if(lst.size() > 10)
            return lst.subList(0, 10);
        else 
            return lst.subList(0,lst.size());
    }
    public static List<util.TweetDetails> getNextTweetsUnCached(HttpSession session, 
        String corp, String fromDate, String toDate,String kw){        
        String user = SessionManager.getCurrentUser(session).getUserId();
        List<util.TweetDetails> lst = TweetCacheManager.GetInstance().
                getUnLabeledTweets(corp, user,fromDate,toDate,kw);        
        return lst;
    }
    
    private static TwitterSentimentManager lookupTwitterSentimentManagerBean() {
        try {
            Context c = new InitialContext();
            return (TwitterSentimentManager) c.lookup("java:global/SentimentWebApp/TwitterSentimentManager!managers.TwitterSentimentManager");
        } catch (NamingException ne) {
            Logger.getLogger(ViewLabelsBean.class.getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }
    ////////////////////////////////////////////////////////////////////////////
    public static List<util.TweetDetails> getNextLabeledTweets(int Page, String corp){        
        
        return ViewLabelsBean.lookupTwitterSentimentManagerBean().GetLabeledTweets(Page, corp);
    }
    public static List<util.TweetDetails> getNextLabeledTweets(String corp, HttpSession session){
        TweetsPager obj = (TweetsPager) session.getAttribute("tweetsPager-" +  corp);
        Integer pageSize = (Integer) session.getAttribute("tweetsPager-pageSize");
        if(pageSize == null) pageSize = 10;
        if( obj == null){
            obj = new TweetsPager( 
                    ViewLabelsBean.lookupTwitterSentimentManagerBean().GetLabeledTweets(corp),
                    pageSize);            
            session.setAttribute("tweetsPager-" +  corp,obj);
        }
        return obj.GetNextPage();        
    }
    
     public static TweetsPager getPager(String corp, HttpSession session){
         TweetsPager obj = (TweetsPager) session.getAttribute("tweetsPager-" +  corp);
         if(obj == null){
            Integer pageSize = (Integer) session.getAttribute("tweetsPager-pageSize");
            if(pageSize == null) pageSize = 10;
            obj = new TweetsPager( 
                ViewLabelsBean.lookupTwitterSentimentManagerBean().GetLabeledTweets(corp),
                pageSize);            
            session.setAttribute("tweetsPager-" +  corp,obj);
         }
         return obj;
     }
     public static TweetsPager setPager(String corp, String fromDate, String toDate, HttpSession session){         
        Integer pageSize = (Integer) session.getAttribute("tweetsPager-pageSize");
        if(pageSize == null) pageSize = 10;
        TweetsPager obj = new TweetsPager( 
                ViewLabelsBean.lookupTwitterSentimentManagerBean().GetLabeledTweets(corp, fromDate, toDate),
                pageSize);            
        session.setAttribute("tweetsPager-" +  corp,obj);
        return obj;
     }
}
