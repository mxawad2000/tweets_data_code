/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui_beans;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Mamoun.Awad
 */
public class StatRecord{
    Map<Integer,Integer> rec = new HashMap<>();
    public void Add(int k){
        if(rec.containsKey(k)){
            Integer v = rec.get(k);
            rec.put(k,v+1);
        }else{
            rec.put(k,1);
        }
    }
    public Integer[] Keys(){
        return rec.keySet().toArray(new Integer[0]);
    }
    public Integer[] Values(){
        return rec.values().toArray(new Integer[0]);
    }
    public int getValue(Integer k){
        if(rec.containsKey(k)) return rec.get(k);
        return 0;
    }
}

