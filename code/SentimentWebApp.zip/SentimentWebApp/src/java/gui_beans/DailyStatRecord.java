/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui_beans;

import static java.lang.System.out;
import java.util.Date;
import java.util.Map;
import java.util.TreeMap;
import util.SentimentLabel;

/**
 *
 * @author Mamoun.Awad
 */

public class DailyStatRecord{
    Map<String,StatRecord> rec = new TreeMap<>();
    /**
     * add tweet statistics
     * @param d
     * @param k 
     */
    public void Add(Date d, int k){
        String date = managers.Util.date2String(d,"yyyy-MM-dd");
        StatRecord v;
        if(rec.containsKey(date)){
            v = rec.get(date);
            v.Add(k);
        }else{
            v = new StatRecord();
            v.Add(k);
            rec.put(date,v);
        }
    }
    public String[] Keys(){
        return rec.keySet().toArray(new String[0]);
    }
    public StatRecord[] Values(){
        return rec.values().toArray(new StatRecord[0]);
    }
    public StatRecord getValue(String key){
        if(rec.containsKey(key)) return rec.get(key);
        return null;
    }
    public int getValue(Date date, Integer k){
        String dateStr = managers.Util.date2String(date,"yyyy-MM-dd");
        if( rec.containsKey(dateStr)){
            return rec.get(dateStr).getValue(k);
        }else return -1;
    }
    /**
     * dateStr should be in the format yyyy-MM-dd
     * @param dateStr
     * @param k
     * @return 
     */
    public int getValue(String dateStr, Integer k){
        if( rec.containsKey(dateStr)){
            return rec.get(dateStr).getValue(k);
        }else return 0;
    }
    public String getXcelString(){
        StringBuilder sb =new StringBuilder();
        StatRecord[] sentValues = Values();
        SentimentLabel[] labels = managers.Util.getSentimentLables();
        sb.append("Date/Label\t");
        for(SentimentLabel label : labels){
            sb.append(label.getLabel()+ "\t");
        }
        sb.append("\n");
        for(String date : Keys()){
            sb.append(date).append("\t");
            StatRecord rec = getValue(date);
            Integer[] sentIds = rec.Keys();
            for(SentimentLabel label : labels){
                sb.append(getValue(date, label.getCode())).append("\t");
            }
            sb.append("\n");
        }
        return sb.toString();
    }
}
