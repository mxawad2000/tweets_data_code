/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets;

import gui_beans.DailyStatRecord;
import gui_beans.LabelTweetsBean;
import gui_beans.TweetsPager;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import managers.SessionManager;
import util.TweetDetails;
/**
 *
 * @author Mamoun.Awad
 */
@WebServlet(name = "TweetsDownloader", urlPatterns = {"/TweetsDownloader"})
public class TweetsDownloader extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {        
        HttpSession session = request.getSession();
        if(!SessionManager.isLoggedIn(session)){//|| !SessionManager.isAdmin(session)){            
            //response.setContentType("text/html;charset=UTF-8");
            System.err.println("user was not logged in............");            
            request.getRequestDispatcher("./home.jsp").forward(request, response);         
            return;
        }            
        /* TODO output your page here. You may use following sample code. */
        Object obj = request.getSession().getAttribute(LabelTweetsBean.TWEET_EXPORT_TAG);
        byte[] file = null;
        if(obj instanceof List){
             List<TweetDetails> lst = (List<TweetDetails>) obj;
             if(lst != null){
                System.out.println(TweetDetails.tweets2Excel(lst));
                file = TweetDetails.tweets2Excel(lst).getBytes();
             }
        }else if(obj instanceof DailyStatRecord){
            DailyStatRecord rec = (DailyStatRecord) obj;
            if(rec != null){
                file = rec.getXcelString().getBytes();
            }
        }else {
            request.setAttribute("msg", "Error: No Tweets/List was found");                    
            request.getRequestDispatcher("./gen_error.jsp").forward(request, response);     
            return;
        }
        ///////////////////////////////////////////////////////////////////
        
        ServletContext context = getServletContext();
        String mimeType = "xls";
        System.out.println("MIME type: " + mimeType);

        // modifies response
        response.setContentType(mimeType);
        response.setContentLength((int)file.length); 
        // forces download
        String headerKey = "Content-Disposition";
        String headerValue = String.format("attachment; filename=\"%s\"", "tweets.xls");
        response.setHeader(headerKey, headerValue);
        OutputStream outStream = response.getOutputStream();
        outStream.write(file);
        outStream.close();
        //////////////////////////////////////////////////////////////////
        //request.setAttribute("msg", "Exporting the tweets in excel.. please open the file once done.");                    
        //request.getRequestDispatcher("./gen_error.jsp").forward(request, response);             
    }
    

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
