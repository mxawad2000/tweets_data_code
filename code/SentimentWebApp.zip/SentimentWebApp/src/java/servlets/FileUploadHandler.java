/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import managers.SessionManager;
import managers.UploadManager;

//look for jar file of these on the website:https://commons.apache.org/proper/commons-fileupload/download_fileupload.cgi
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.fileupload.servlet.ServletRequestContext;


/**
 *
 * @author Mamoun.Awad
 */

public class FileUploadHandler extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet FileUploadHandler</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet FileUploadHandler at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //process only if its multipart content
        HttpSession session = request.getSession();
        if(!SessionManager.isLoggedIn(session)|| !SessionManager.isAdmin(session)){            
            System.err.println("user was not logged in............");
            request.getRequestDispatcher("./login.jsp").forward(request, response);         
            return;
        }
        String fileName = null;
        String uType = null;
        String referrer = request.getHeader("referer");
        request.setAttribute("back", referrer);
        if (ServletFileUpload.isMultipartContent(request)) {
            try {
                List<FileItem> multiparts = new ServletFileUpload(
                        new DiskFileItemFactory()).
                        parseRequest(new ServletRequestContext(request));                
                for (FileItem item : multiparts) {
                    if (item.isFormField() && item.getFieldName().equals("uType")) {
                        uType = item.getString();break;
                    }
                }
                if(uType ==null){
                    request.setAttribute("msg", "Error: No type was selected");                    
                    request.getRequestDispatcher("./gen_error.jsp").forward(request, response);                    
                    System.out.println("uType is null..........................");
                }else{
                    System.out.println("Utype:"+ uType);
                }
                
                for (FileItem item : multiparts) {
                    if (!item.isFormField()) {
                        String name = new File(item.getName()).getName();
                        int N = UploadManager.getInstance().processStream(item.getInputStream(),uType);
                        request.setAttribute("msg", "File Uploaded Successfully, number of records:" + N);                            
                        request.getRequestDispatcher("./gen_error.jsp").forward(request, response);                                        
                        break;
                    } 
                }
                //File uploaded successfully
            } catch (Exception ex) {
                request.setAttribute("msg", "File Upload Failed due to " + ex);
                ex.printStackTrace();
            }
        } else {
               request.setAttribute("msg",
                    "Sorry this Servlet only handles file upload request");
            request.getRequestDispatcher("./gen_error.jsp").forward(request, response);
         
        }
    }


    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
