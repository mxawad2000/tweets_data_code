/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package managers;

import javax.servlet.http.HttpSession;

/**
 *
 * @author Mamoun.Awad
 */
public class SessionManager {

    public static final String ROLE_TAG = "role-tag";
    public static final String USER_OBJ_TAG = "user-object-tag";
    public static final String ADMIN_ROLE = "0";
    public static final String USER_ROLE = "1";

    public static boolean isLoggedIn(HttpSession session) {
        return session.getAttribute(USER_OBJ_TAG) != null;
    }

    public static String getName(HttpSession session) {
        UserT user = ((LoginRecord) session.getAttribute(USER_OBJ_TAG)).getUser();
        return user.getLname() + ", " + user.getFname();
    }

    public static boolean isAdmin(HttpSession session) {
        UserT user = ((LoginRecord) session.getAttribute(USER_OBJ_TAG)).getUser();
        return user != null && user.getRole().equals(ADMIN_ROLE);

    }

    public static boolean isRegularUser(HttpSession session) {
        UserT user = ((LoginRecord) session.getAttribute(USER_OBJ_TAG)).getUser();
        return user != null && user.getRole().equals(USER_ROLE);

    }

    public static UserT getCurrentUser(HttpSession session) {
        return ((LoginRecord) session.getAttribute(USER_OBJ_TAG)).getUser();
    }

    public static void handleLogout(HttpSession session) {
        if (!SessionManager.isLoggedIn(session)) {
            return;
        }
        session.removeAttribute(USER_OBJ_TAG);
        session.invalidate();
    }
}
