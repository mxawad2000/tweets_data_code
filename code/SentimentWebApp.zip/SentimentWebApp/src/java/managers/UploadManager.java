/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package managers;

import java.io.*;
import java.util.Arrays;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

/**
 *
 * @author Mamoun.Awad
 */
public class UploadManager {

    TwitterSentimentManager twitterSentimentManager = lookupTwitterSentimentManagerBean();
    private static UploadManager Instance = new UploadManager();
    private UploadManager(){}
    public static UploadManager getInstance(){ return Instance;}
    ///////////////////////////////////////////////////////
    public String getTmpFileName(){
        Date d = new Date();
        return d.getTime() + ".txt";
    }

    public int processStream(InputStream stream, String corp){
        int ind;
        BufferedReader br = new BufferedReader(new InputStreamReader(stream));
        try{       
            System.out.println("Corp:" + corp);
            String line  = null;
            int count = 0;
            while((line = br.readLine()) != null){
                String[] fields = line.split("\\|\\|");                
                for(int i=0;i<fields.length;i++){
                    ind = fields[i].indexOf(":");
                    if(ind != -1) fields[i] = fields[i].substring(ind+1);
                }
                //System.out.println("Fields:" + Arrays.toString(fields));
                try{
                    count += lookupTwitterSentimentManagerBean().persist(fields, corp);                    
                }catch(Exception exx){}                
            }
            return count;
        }catch(Exception ex){
            System.out.println("Error in reading:" + ex.getMessage());
            return 0;
        }finally{
            if(br != null) try{br.close();}catch(Exception exx){}
        }
    }

    private TwitterSentimentManager lookupTwitterSentimentManagerBean() {
        try {
            Context c = new InitialContext();
            return (TwitterSentimentManager) c.lookup("java:global/SentimentWebApp/TwitterSentimentManager!managers.TwitterSentimentManager");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }
}
