/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package managers;

import static com.sun.xml.ws.security.impl.policy.Constants.logger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import util.*;
/**
 *
 * @author Mamoun.Awad
 */
public class AccountManager {

    UsersSessionBean usersSessionBean = lookupUsersSessionBeanBean();  
    
    private static AccountManager Instance = new AccountManager();
    public AccountManager(){}
    public static AccountManager getInstance(){ return Instance;}
    ///////////////////////////////////////////////////////////////////////////
    
    public UserT validateLogin2(String userId, String pw){
        managers.TweetCacheManager.GetInstance();
        return usersSessionBean.validateLogin(userId, pw);        
        
    }
    static final UserT EMPTY_USER= new UserT();
    public static UserT GetEmptyUser(){
        EMPTY_USER.setEmail("");EMPTY_USER.setFname("");
        EMPTY_USER.setLname("");EMPTY_USER.setRole("1");
        EMPTY_USER.setUserId("");
        return EMPTY_USER;
    }
    /**
     * find user by id
     * @param userId
     * @return 
     */
    public UserT find(String userId){
        return usersSessionBean.getUser(userId);
    }
    public boolean addUser(UserT user){        
        if(this.usersSessionBean.getUser(user.getUserId()) != null ){
            return false;
        }
        this.usersSessionBean.persist(user);
        return true;
    }
    public boolean matchPassword(UserT user, String pw){
        return usersSessionBean.matchPassword(user, pw);
    }
    public boolean matchPassword(String userId, String pw){
        return usersSessionBean.matchPassword(userId, pw);
    }
    public boolean resetPassword(UserT user, String pw){        
        usersSessionBean.updatePassword(user, pw);
        return true;
    }
    public static Account validateLogin(String userID, String pw) {
        String query = "select fname,lname,role,email from user_t WHERE user_id=? and "
                + "password=md5(concat(?,'.',?)) ";       
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Account account = null;
        try {
            conn = DBConnection.getInstance().getConnection();
            stmt = conn.prepareStatement(query);
            stmt.setString(1, userID);
            stmt.setString(2,userID);
            stmt.setString(3,pw);
            rs = stmt.executeQuery();               
            
            if(rs.next()){
                account = new Account();
                account.setLoginID(userID);
                account.setLoginID(rs.getString(1));
                account.setName(rs.getString(1),rs.getString(2));
                account.setEmail(rs.getString(4));
                account.setRole(rs.getInt(3));                
                return account;
            }            
        } catch (Exception ex) {
            logger.info( "exception in running query:" + 
                    query + ex.getMessage());
            ex.printStackTrace();            
        } finally {
            if (stmt != null) {try {stmt.close();}catch (Exception ex1) { }}
            if (rs != null) {try {rs.close();} catch (Exception ex1) {}}
            if (conn != null) {try { conn.close();} catch (Exception ex1) {}}            
        }
        return null;
    }

    private UsersSessionBean lookupUsersSessionBeanBean() {
        try {
            Context c = new InitialContext();
            return (UsersSessionBean) c.lookup("java:global/SentimentWebApp/UsersSessionBean!managers.UsersSessionBean");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }
}
