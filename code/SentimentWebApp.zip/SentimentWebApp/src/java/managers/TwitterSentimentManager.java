/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package managers;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Root;
import java.sql.Connection;
import java.sql.*;
import java.util.HashSet;

/**
 *
 * @author Mamoun.Awad
 */
@Stateless
public class TwitterSentimentManager {

    @PersistenceContext(unitName = "SentimentWebAppPU")
    private EntityManager em;    
    public void persist(Object object) {
        em.persist(object);
    }
    public int persist(String[] record, String corp){
        int count = 0;
        TwitterT tweet = new TwitterT();
        tweet.setTweetId(record[0]);tweet.setTwUser(record[1]);               
        try{
            //Thu Oct 05 02:44:24 GST 2017
            SimpleDateFormat format = new SimpleDateFormat("EEE MMM d HH:mm:ss z yyyy");
            tweet.setTwDate(format.parse(record[2])); 
        }catch(Exception ex){
            System.out.println("Error parsing:" + ex.getMessage() +  "-->" + Arrays.toString(record));
        }
        tweet.setTwText(record[3]);
        tweet.setTwLang(record[4]); tweet.setTwLocation(record[5]);
        SentimentT sent = new SentimentT();
        sent.setMSentiment(Integer.parseInt(record[6]));
        sent.setHSentiment(-1);
        sent.setSentimentTPK(new SentimentTPK(tweet.getTweetId(),corp));        
        if( em.find(TwitterT.class, tweet.getTweetId()) == null) {em.persist(tweet);count++;}                
        if(em.find(SentimentT.class,sent.getSentimentTPK()) == null) {em.persist(sent);count++;}
        return count;
    }
    
    public void persistOrUpdateSentiment(String[] tweetIds, String[] h_code, String corp, String userId){
        Query q = em.createQuery(
              "UPDATE SentimentT S SET S.hSentiment=:sent WHERE S.sentimentTPK.corp=:corp AND S.sentimentTPK.tweetId=:tid");
        for(int i=0;i<tweetIds.length;i++){
                if(h_code[i].equals("-1")) continue;            
                q.setParameter("sent", Integer.parseInt(h_code[i]));
                q.setParameter("corp", corp);
                q.setParameter("tid", tweetIds[i]);
                int r = q.executeUpdate();
        }
        Connection conn =null;
        PreparedStatement stmt=null ;
        try{
            String insertQ = "INSERT INTO LABEL_USER_T VALUES (?,?,?)";
            conn = DBConnection.getInstance().getConnection();
            stmt = conn.prepareStatement(insertQ);
            for(int i=0;i<tweetIds.length;i++){
                if(h_code[i].equals("-1")) continue;                        
                //keep record for the user who inserted this labels of the tweets.
                stmt.setString(1, tweetIds[i]);
                stmt.setString(2, corp);
                stmt.setString(3, userId);
                stmt.executeUpdate();                        
            }
        }catch(Exception ex){
            ex.printStackTrace();
        }finally{
            if(conn != null) try{conn.close();}catch(Exception e){}
            if(stmt != null) try{stmt.close();}catch(Exception e){}
        }
        em.flush();
        em.clear();        
    }
    public void InsertUserLabel(String user, String corp, String tweet_id){
        Connection conn = null;
        PreparedStatement stmt = null;
        try{
            String q = "INSERT INTO LABEL_USER_T VALUES (?,?,?)";
            conn = DBConnection.getInstance().getConnection();
            stmt = conn.prepareStatement(q);
            stmt.setString(1, tweet_id);
            stmt.setString(2, corp);
            stmt.setString(3, user);
            stmt.executeUpdate();                        
        }catch(Exception ex){
            ex.printStackTrace();
        }finally{
            if(conn != null) try{conn.close();}catch(Exception e){}
            if(stmt != null) try{stmt.close();}catch(Exception e){}
        }
    }
    public void InsertUserLabel(PreparedStatement stmt, String user, String corp, String tweet_id){        
        try{          
            stmt.setString(1, tweet_id);
            stmt.setString(2, corp);
            stmt.setString(3, user);
            stmt.executeUpdate();                        
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }
    /**
     * Getting N random tweets for a given corp, fromDate, toDate, and keyword.
     * @param N
     * @param corp
     * @param fromDate
     * @param toDate
     * @param kw
     * @return 
     */
    public List<util.TweetDetails> GetTweets(int N, String corp, String fromDate, 
                                            String toDate,String kw){        
        if(fromDate == null || fromDate.isEmpty()) fromDate = "2000-01-01";
        if(toDate == null || toDate.isEmpty()) toDate = "2050-01-01";
        java.util.Date fDate = Util.parseDate(fromDate, "yyyy-MM-dd");
        java.util.Date tDate = Util.parseDate(toDate, "yyyy-MM-dd");        
        System.out.println("fDate:" + fDate);
        System.out.println("tDate:" + tDate);
        
        TypedQuery<util.TweetDetails> query2 = em.createQuery(
         "SELECT new util.TweetDetails(T , S.mSentiment) FROM TwitterT T LEFT JOIN T.sentimentTCollection S WHERE S.hSentiment=-1 AND " +
                "S.sentimentTPK.corp=:corp AND T.twDate >=:date1 AND T.twDate<=:date2 AND T.twText LIKE :kw", 
                util.TweetDetails.class);        
        query2.setParameter("corp", corp);
        query2.setParameter("date1",fDate);
        query2.setParameter("date2",tDate);
        query2.setParameter("kw","%" + kw + "%");
        List<util.TweetDetails> tweets = query2.getResultList();                
        if(tweets == null) return new ArrayList<>();
        //select random N 
        if(tweets.size() <= N ) return tweets;
        int M = tweets.size() - N;
        for(int i=0;i<M;i++){            
            int r = Util.getRandomInt(tweets.size());
            Object o = tweets.remove(r);                        
        }
        System.out.println("Returning tweets of size:" + tweets.size());
        return tweets;
    }
    /**
     * same as getweet but with java search
     * @param N
     * @param corp
     * @param fromDate
     * @param toDate
     * @param kw
     * @return 
     */
    public List<util.TweetDetails> GetTweets(String corp, String fromDate, 
                                            String toDate){        
        if(fromDate == null || fromDate.isEmpty()) fromDate = "2000-01-01";
        if(toDate == null || toDate.isEmpty()) toDate = "2050-01-01";
        java.util.Date fDate = Util.parseDate(fromDate, "yyyy-MM-dd");
        java.util.Date tDate = Util.parseDate(toDate, "yyyy-MM-dd");        
        System.out.println("fDate:" + fDate);
        System.out.println("tDate:" + tDate);
        
        TypedQuery<util.TweetDetails> query2 = em.createQuery(
         "SELECT new util.TweetDetails(T , S.mSentiment) FROM TwitterT T LEFT JOIN T.sentimentTCollection S WHERE S.hSentiment=-1 AND " +
                "S.sentimentTPK.corp=:corp AND T.twDate >=:date1 AND T.twDate<=:date2", 
                util.TweetDetails.class);        
        query2.setParameter("corp", corp);
        query2.setParameter("date1",fDate);
        query2.setParameter("date2",tDate);
        //query2.setParameter("kw","%" + kw + "%");
        List<util.TweetDetails> tweets = query2.getResultList();                        
        System.out.println("Returning tweets of SIZE:" + tweets.size());
        return tweets;
    }
    /**
     * getting a randeom N tweets for a given corporation.
     * @param N
     * @param corp
     * @return 
     */
    public List<util.TweetDetails> GetTweets(int N, String corp){        
        TypedQuery<util.TweetDetails> query2 = em.createQuery(
         "SELECT new util.TweetDetails(T , S.mSentiment) FROM TwitterT T LEFT JOIN T.sentimentTCollection S WHERE S.hSentiment=-1 AND " +
                "S.sentimentTPK.corp=:corp", util.TweetDetails.class);        
        query2.setParameter("corp", corp);
        List<util.TweetDetails> tweets = query2.getResultList();                
        if(tweets == null) return new ArrayList<>();
        //select random N 
        if(tweets.size() <= N ) return tweets;
        int M = tweets.size() - N;
        for(int i=0;i<M;i++){            
            int r = Util.getRandomInt(tweets.size());
            Object o = tweets.remove(r);                        
        }
        System.out.println("Returning tweets of size:" + tweets.size());
        return tweets;
    }
    public List<util.TweetDetails> GetLabeledTweets(String corp){                 
        TypedQuery<util.TweetDetails> query2 = em.createQuery(
         "SELECT new util.TweetDetails(T,S.mSentiment,S.hSentiment) FROM TwitterT T LEFT JOIN T.sentimentTCollection S WHERE S.hSentiment<>-1 AND " +
                "S.sentimentTPK.corp=:corp", util.TweetDetails.class);        
        query2.setParameter("corp", corp);
        List<util.TweetDetails> tweets = query2.getResultList(); 
        if(tweets == null) return new ArrayList<>();
        for(util.TweetDetails tw : tweets) tw.setCorp(corp);
        return tweets;
    }
   
     /**
      * retrieve only labeled tweets (by human) with certain date criteria
      * @param corp
      * @param fromDate
      * @param toDate
      * @return 
      */
    public List<util.TweetDetails> GetLabeledTweets(String corp, String fromDate, String toDate){        
        if(fromDate == null || fromDate.isEmpty()) fromDate = "2000-01-01";
        if(toDate == null || toDate.isEmpty()) toDate = "2050-01-01";
        java.util.Date fDate = Util.parseDate(fromDate, "yyyy-MM-dd");
        java.util.Date tDate = Util.parseDate(toDate, "yyyy-MM-dd");                       
        TypedQuery<util.TweetDetails> query2 = em.createQuery(
         "SELECT new util.TweetDetails(T,S.mSentiment,S.hSentiment) FROM TwitterT T LEFT JOIN T.sentimentTCollection S WHERE S.hSentiment<>-1 AND " +
                "S.sentimentTPK.corp=:corp AND T.twDate >=:date1 AND T.twDate<=:date2", util.TweetDetails.class);        
        query2.setParameter("corp", corp);        
        query2.setParameter("date1",fDate);
        query2.setParameter("date2",tDate);        
        List<util.TweetDetails> tweets = query2.getResultList();                
        if(tweets == null) return new ArrayList<>();
        for(util.TweetDetails tw : tweets) tw.setCorp(corp);
        System.out.println("Returning tweets of size:" + tweets.size());
        return tweets;
    }
     /**
     * Each page is 100 tweets.
     * @param page
     * @param corp
     * @return 
     */
    public List<util.TweetDetails> GetLabeledTweets(int page, String corp){        
        int PageSize = 100;
        TypedQuery<util.TweetDetails> query2 = em.createQuery(
         "SELECT new util.TweetDetails(T,S.mSentiment,S.hSentiment) FROM TwitterT T LEFT JOIN T.sentimentTCollection S WHERE S.hSentiment<>-1 AND " +
                "S.sentimentTPK.corp=:corp", util.TweetDetails.class);        
        query2.setParameter("corp", corp);
        List<util.TweetDetails> tweets = query2.getResultList();                
        List<util.TweetDetails> pageList = new ArrayList<>();
        if(tweets == null) return pageList;
        int start = (page-1) * PageSize;        
        for(int i=0;i<PageSize;i++){         
            int index = i+start;
            if(index >= tweets.size()) break;
            pageList.add(tweets.get(index));
        }
        System.out.println("Returning tweets of size:" + pageList.size());
        return pageList;
    }
    public List<TwitterT> GetTweetsaaa(int N, String corp){
        TypedQuery<String> query2 = em.createQuery(
         "SELECT S.sentimentTPK.tweetId FROM SentimentT S WHERE S.hSentiment=:value AND S.sentimentTPK.corp=:company"         
                , String.class);        
        query2.setParameter("value", -1);
        query2.setParameter("company", corp);
        List<String> twList = query2.getResultList();        
        
        if(twList == null || twList.isEmpty()) return new ArrayList<TwitterT>();
        TypedQuery<TwitterT> query = em.createQuery("SELECT t FROM TwitterT t WHERE t.tweetId IN :list", 
                TwitterT.class);
        query.setParameter("list", twList);
        List<TwitterT> tweets = query.getResultList();        
        if(tweets == null || tweets.isEmpty()) 
            return new ArrayList<TwitterT>();        
        //select random N 
        if(tweets.size() <= N ) return tweets;
        int M = tweets.size() - N;
        for(int i=0;i<M;i++){
            int r = Util.getRandomInt(tweets.size());
            tweets.remove(r);
        }
        System.out.println("Returning tweets of size:" + tweets.size());
        return tweets;
    }
    
    public String[] GetCorporations(){
        TypedQuery<String> query = em.createQuery(
         "SELECT DISTINCT S.sentimentTPK.corp FROM SentimentT S"
                , String.class);        
        List<String> twList = query.getResultList();        
        return twList.toArray(new String[0]);
    }

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
}
