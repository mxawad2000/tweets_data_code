/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package managers;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Mamoun.Awad
 */
@Entity
@Table(name = "sentiment_t")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "SentimentT.findAll", query = "SELECT s FROM SentimentT s"),
    @NamedQuery(name = "SentimentT.findByTweetId", query = "SELECT s FROM SentimentT s WHERE s.sentimentTPK.tweetId = :tweetId"),
    @NamedQuery(name = "SentimentT.findByCorp", query = "SELECT s FROM SentimentT s WHERE s.sentimentTPK.corp = :corp"),
    @NamedQuery(name = "SentimentT.findByMSentiment", query = "SELECT s FROM SentimentT s WHERE s.mSentiment = :mSentiment"),
    @NamedQuery(name = "SentimentT.findByHSentiment", query = "SELECT s FROM SentimentT s WHERE s.hSentiment = :hSentiment")})
public class SentimentT implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected SentimentTPK sentimentTPK;
    @Column(name = "m_sentiment")
    private Integer mSentiment;
    @Column(name = "h_sentiment")
    private Integer hSentiment;
    @JoinColumn(name = "tweet_id", referencedColumnName = "tweet_id", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private TwitterT twitterT;

    public SentimentT() {
    }

    public SentimentT(SentimentTPK sentimentTPK) {
        this.sentimentTPK = sentimentTPK;
    }

    public SentimentT(String tweetId, String corp) {
        this.sentimentTPK = new SentimentTPK(tweetId, corp);
    }

    public SentimentTPK getSentimentTPK() {
        return sentimentTPK;
    }

    public void setSentimentTPK(SentimentTPK sentimentTPK) {
        this.sentimentTPK = sentimentTPK;
    }

    public Integer getMSentiment() {
        return mSentiment;
    }

    public void setMSentiment(Integer mSentiment) {
        this.mSentiment = mSentiment;
    }

    public Integer getHSentiment() {
        return hSentiment;
    }

    public void setHSentiment(Integer hSentiment) {
        this.hSentiment = hSentiment;
    }

    public TwitterT getTwitterT() {
        return twitterT;
    }

    public void setTwitterT(TwitterT twitterT) {
        this.twitterT = twitterT;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (sentimentTPK != null ? sentimentTPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof SentimentT)) {
            return false;
        }
        SentimentT other = (SentimentT) object;
        if ((this.sentimentTPK == null && other.sentimentTPK != null) || (this.sentimentTPK != null && !this.sentimentTPK.equals(other.sentimentTPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "managers.SentimentT[ sentimentTPK=" + sentimentTPK + " ]";
    }
    
}
