/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package managers;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

/**
 *
 * @author Mamoun.Awad
 */
public class TweetCacheManager {

    TwitterSentimentManager twitterSentimentManager = lookupTwitterSentimentManagerBean();
    private static TweetCacheManager Instance ;
    private TweetCacheManager(){}
    public static TweetCacheManager GetInstance( ) { 
        synchronized(TweetCacheManager.class){
            if(Instance == null){
                Instance = new TweetCacheManager();
            }
        }
        return Instance;
    }
    /////////////////////////////////////////////////////////////
    private Map<String,List<util.TweetDetails>> currentMap= new HashMap<>();
    private static final List<TwitterT> EMPTY_TWEET_LIST = new ArrayList<TwitterT>();
    public String[] getAllCorps(){
        return this.lookupTwitterSentimentManagerBean().GetCorporations();
    }
    
    public List<util.TweetDetails> getUnLabeledTweets(String corp, String userId){
       String key = corp + "-" + userId;
        System.out.println("getting new unlabled list for:" + key);
       List<util.TweetDetails> currList = currentMap.get(key);
       if(currList == null) currList =new ArrayList<>();
        if(currList.size() < 20){
            List<util.TweetDetails> bufList = 
                    this.lookupTwitterSentimentManagerBean().
                            GetTweets(100, corp);
            if(bufList.isEmpty()) return currList;                        
            for(int i=0;i<bufList.size();i++){               
                util.TweetDetails t = bufList.get(i);
                if(!currList.contains(t)) currList.add(t);
            }            
        }
        return currList;                       
    } 
    public List<util.TweetDetails> getUnLabeledTweets(String corp, String userId, 
            String fromDate, String toDate, String kw){
            List<util.TweetDetails> bufList = 
                    this.lookupTwitterSentimentManagerBean().
                            GetTweets(100, corp,fromDate,toDate,kw);
        return bufList;                       
    } 
    public List<TwitterT> getUnLabeledTweets2(String corp, String userId){
        TwitterT t = new TwitterT();
        t.setTweetId("10");
        List<TwitterT> lst =new ArrayList<>();
        lst.add(t);
        return lst;
    } 
    /*
    public List<TwitterT> getTweets(int N){
        return null;
    }
*/
    
    private TwitterSentimentManager lookupTwitterSentimentManagerBean() {
        try {
            Context c = new InitialContext();
            return (TwitterSentimentManager) c.lookup("java:global/SentimentWebApp/TwitterSentimentManager!managers.TwitterSentimentManager");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }
}
