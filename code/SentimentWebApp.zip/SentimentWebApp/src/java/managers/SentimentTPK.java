/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package managers;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author Mamoun.Awad
 */
@Embeddable
public class SentimentTPK implements Serializable {

    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 30)
    @Column(name = "tweet_id")
    private String tweetId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 30)
    @Column(name = "corp")
    private String corp;

    public SentimentTPK() {
    }

    public SentimentTPK(String tweetId, String corp) {
        this.tweetId = tweetId;
        this.corp = corp;
    }

    public String getTweetId() {
        return tweetId;
    }

    public void setTweetId(String tweetId) {
        this.tweetId = tweetId;
    }

    public String getCorp() {
        return corp;
    }

    public void setCorp(String corp) {
        this.corp = corp;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (tweetId != null ? tweetId.hashCode() : 0);
        hash += (corp != null ? corp.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof SentimentTPK)) {
            return false;
        }
        SentimentTPK other = (SentimentTPK) object;
        if ((this.tweetId == null && other.tweetId != null) || (this.tweetId != null && !this.tweetId.equals(other.tweetId))) {
            return false;
        }
        if ((this.corp == null && other.corp != null) || (this.corp != null && !this.corp.equals(other.corp))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "managers.SentimentTPK[ tweetId=" + tweetId + ", corp=" + corp + " ]";
    }
    
}
