/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package managers;

import java.security.MessageDigest;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

/**
 *
 * @author Mamoun.Awad
 */
@Stateless
public class UsersSessionBean {

    @PersistenceContext(unitName = "SentimentWebAppPU")
    private EntityManager em;

    public void persist(UserT user) {        
        em.persist(user);
    }
    public List<UserT> getAllUsers(){
        TypedQuery<UserT> query = em.createQuery(
            "SELECT u FROM UserT u", UserT.class);
        return query.getResultList();
    }
    public UserT getUser(String userId){
        for(UserT u : getAllUsers()){
            System.out.println("User:" + u);
            if(u.getUserId().equals(userId)) return u;
        }
        
        return null;
    }
    public boolean matchPassword(UserT user, String pw){
        String hPw = Util.MD5(user.getUserId() + "." + pw);        
        return user.getPassword().equals(hPw);
    }
    public boolean matchPassword(String userId, String pw){
        UserT user = this.getUser(userId);
        String hPw = Util.MD5(user.getUserId() + "." + pw);
        return user.getPassword().equals(hPw);
    }
    
    public void updatePassword(UserT user, String newPW){
        String hpw = Util.MD5(user.getUserId()+"." + newPW);        
        String queryStr = String.format("UPDATE UserT e SET e.password = '%s' WHERE e.userId = '%s'",
                hpw,user.getUserId());
        Query query = em.createQuery(queryStr);
        query.executeUpdate();        
        user.setPassword(hpw);
    }
    public UserT validateLogin(String userId, String pw){
        String dMsg="";
        try{
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] msg = (userId+"."+pw).getBytes();
            byte[] oMsg = md.digest(msg);
             StringBuffer sb = new StringBuffer();
            for (int i = 0; i < oMsg.length; i++) {
                sb.append(Integer.toString((oMsg[i] & 0xff) + 0x100, 16).substring(1));
            }
            dMsg = sb.toString();
            System.out.println("Out Msg:" + dMsg);
        }catch(Exception ex){
            System.out.println("Something is wrong.....");
            ex.printStackTrace();
        }
        for(UserT u : getAllUsers()){
            System.out.println("User:" + u);
            if(u.getUserId().equals(userId) && u.getPassword().equals(dMsg) )
                return u;
        }
        return null;
    }
    

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
    
}
