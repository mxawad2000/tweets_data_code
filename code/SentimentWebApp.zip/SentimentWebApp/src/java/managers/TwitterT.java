/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package managers;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Mamoun.Awad
 */
@Entity
@Table(name = "twitter_t")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "TwitterT.findAll", query = "SELECT t FROM TwitterT t"),
    @NamedQuery(name = "TwitterT.findByTweetId", query = "SELECT t FROM TwitterT t WHERE t.tweetId = :tweetId"),
    @NamedQuery(name = "TwitterT.findByTwUser", query = "SELECT t FROM TwitterT t WHERE t.twUser = :twUser"),
    @NamedQuery(name = "TwitterT.findByTwDate", query = "SELECT t FROM TwitterT t WHERE t.twDate = :twDate"),
    @NamedQuery(name = "TwitterT.findByTwText", query = "SELECT t FROM TwitterT t WHERE t.twText = :twText"),
    @NamedQuery(name = "TwitterT.findByTwLang", query = "SELECT t FROM TwitterT t WHERE t.twLang = :twLang"),
    @NamedQuery(name = "TwitterT.findByTwLocation", query = "SELECT t FROM TwitterT t WHERE t.twLocation = :twLocation")})
public class TwitterT implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 30)
    @Column(name = "tweet_id")
    private String tweetId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 32)
    @Column(name = "tw_user")
    private String twUser;
    @Column(name = "tw_date")
    @Temporal(TemporalType.DATE)
    private Date twDate;
    @Size(max = 400)
    @Column(name = "tw_text")
    private String twText;
    @Size(max = 30)
    @Column(name = "tw_lang")
    private String twLang;
    @Size(max = 30)
    @Column(name = "tw_location")
    private String twLocation;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "twitterT")
    private Collection<SentimentT> sentimentTCollection;

    public TwitterT() {
    }

    public TwitterT(String tweetId) {
        this.tweetId = tweetId;
    }

    public TwitterT(String tweetId, String twUser) {
        this.tweetId = tweetId;
        this.twUser = twUser;
    }

    public String getTweetId() {
        return tweetId;
    }

    public void setTweetId(String tweetId) {
        this.tweetId = tweetId;
    }

    public String getTwUser() {
        return twUser;
    }

    public void setTwUser(String twUser) {
        this.twUser = twUser;
    }

    public Date getTwDate() {
        return twDate;
    }

    public void setTwDate(Date twDate) {
        this.twDate = twDate;
    }

    public String getTwText() {
        return twText;
    }

    public void setTwText(String twText) {
        this.twText = twText;
    }

    public String getTwLang() {
        return twLang;
    }

    public void setTwLang(String twLang) {
        this.twLang = twLang;
    }

    public String getTwLocation() {
        return twLocation;
    }

    public void setTwLocation(String twLocation) {
        this.twLocation = twLocation;
    }

    @XmlTransient
    public Collection<SentimentT> getSentimentTCollection() {
        return sentimentTCollection;
    }

    public void setSentimentTCollection(Collection<SentimentT> sentimentTCollection) {
        this.sentimentTCollection = sentimentTCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (tweetId != null ? tweetId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TwitterT)) {
            return false;
        }
        TwitterT other = (TwitterT) object;
        if ((this.tweetId == null && other.tweetId != null) || (this.tweetId != null && !this.tweetId.equals(other.tweetId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "managers.TwitterT[ tweetId=" + tweetId + " ]";
    }
    
}
