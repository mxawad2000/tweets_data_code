package managers;

/**
 *
 * @author Mamoun.Awad
 */
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Mamoun.Awad
 */
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.DriverManager;
import javax.sql.DataSource;
import javax.naming.InitialContext;

public class DBConnection {

    private static DBConnection Instance = new DBConnection();
    private DBConnection(){}
    public static DBConnection getInstance(){ return Instance; }
    
    //@Resource(name="jdbc/myDatasource") javax.sql.DataSource ds;
    //@Resource(name="jdbc/sentimentResource") javax.sql.DataSource ds;
    public Connection getConnectionxx() throws Exception {
        InitialContext initialContext = new InitialContext();
        //Context ctx = (Context) initialContext.lookup("java:comp/env");
        //The JDBC Data source that we just created
        //System.err.println("Env:" + initialContext.getEnvironment());
        //System.out.println(initialContext.getNameInNamespace());
        
        DataSource ds = (DataSource) initialContext.lookup("jdbc/sentimentResource");
        Connection connection = ds.getConnection();
        
        if (connection == null) {            
            throw new SQLException("Error establishing connection!");
        }        
        return connection;    
    }
    public Connection getConnection() throws Exception {
        Class.forName("com.mysql.jdbc.Driver");  
        Connection con=DriverManager.getConnection(  
            "jdbc:mysql://localhost:3306/sentiments","mamoun","mamoun");          
        if (con == null) {            
            throw new SQLException("Error establishing connection!");
        }        
        return con;    
    }
}
