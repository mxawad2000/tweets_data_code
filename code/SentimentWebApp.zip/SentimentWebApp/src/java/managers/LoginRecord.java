/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package managers;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionBindingListener;
import javax.servlet.http.HttpSessionEvent;

/**
 *
 * @author Mamoun.Awad
 */
public class LoginRecord implements HttpSessionBindingListener {

    // All logins.
    private static Map<LoginRecord, HttpSession> logins = new ConcurrentHashMap<>();
    public LoginRecord(){}
    public LoginRecord(UserT user){ this.user =user;}
    // Normal properties.
    private UserT user;
    // Etc.. Of course with public getters+setters.
    public UserT getUser(){ return user;}
    
    @Override
    public boolean equals(Object other) {
        if(other != null && other instanceof LoginRecord){
            LoginRecord oRec = (LoginRecord) other;
            return user.equals(oRec.user);
        }
        return false;
    }

    @Override
    public int hashCode() {
        return user.hashCode();
    }

    @Override
    public void valueBound(HttpSessionBindingEvent event){
        ///System.out.println("Someone was logged in:" + 
               // ( this.user != null ? user.getUserId() : "NULL"));
        HttpSession session = logins.remove(this);
        if (session != null) {
            session.invalidate();
        }else{
            //System.out.println("session was not found....");
        }
        logins.put(this, event.getSession());
    }
    public void sessionCreated(HttpSessionEvent event) {
        
    }  
    
    @Override
    public void valueUnbound(HttpSessionBindingEvent e){
        //System.out.println("Someone was logged out....");
        logins.remove(this);
    }    

}