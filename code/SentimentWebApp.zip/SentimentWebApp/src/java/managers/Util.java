/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package managers;

import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;

/**
 *
 * @author Mamoun.Awad
 */
public class Util {
    public static final Map<Integer,String> SentimentMap = new TreeMap<Integer,String>();
    static{
        SentimentMap.put(-1,"Missing");
        SentimentMap.put(0,"Very Negative");
        SentimentMap.put(1,"Negative");
        SentimentMap.put(2,"Neutral");
        SentimentMap.put(3,"Positive");
        SentimentMap.put(4,"very positive");
        SentimentMap.put(5,"advertisement");
        SentimentMap.put(6,"others");
    };
    public static String getSentimentStr(int id){ return SentimentMap.get(id);}
    public static int getSentimentCode(String name){
        Iterator<Integer> iter =SentimentMap.keySet().iterator();
        while(iter.hasNext()){
            int id = iter.next();
            if(SentimentMap.get(id).equals(name)) return id;
        }
        return 6;
    }
    public static String[] getSentimentNames(){
        List<String> lst = new ArrayList<>();
        Iterator<String> iter =SentimentMap.values().iterator();
        while(iter.hasNext()){
            lst.add(iter.next());
        }
        return lst.toArray(new String[0]);
    }
    public static util.SentimentLabel[] getSentimentLables(){
        List<util.SentimentLabel> lst = new ArrayList<>();
        Iterator<Integer> iter =SentimentMap.keySet().iterator();
        while(iter.hasNext()){
            int code = iter.next();
            lst.add(new util.SentimentLabel(code, SentimentMap.get(code)));
        }
        return lst.toArray(new util.SentimentLabel[0]);
    }
    
    private static Random rand = new Random(System.currentTimeMillis());
    public static int getRandomInt(int Max){
        return rand.nextInt(Max);
    }
    public static int getRandomInt(int from, int Max){
        return rand.nextInt(Max - from ) + from;
    }
    public static String MD5(String orgMsg){
        String dMsg="";
        try{
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] msg = orgMsg.getBytes();
            byte[] oMsg = md.digest(msg);
             StringBuffer sb = new StringBuffer();
            for (int i = 0; i < oMsg.length; i++) {
                sb.append(Integer.toString((oMsg[i] & 0xff) + 0x100, 16).substring(1));
            }
            dMsg = sb.toString();
            System.out.println("Out Msg:" + dMsg);
            return dMsg;
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return "";
    }
    public static void prepareUser(UserT user){
        user.setCreationDate(new Date());
        user.setPassword(MD5(user.getUserId() +"." + user.getUserId()));
    }
    public static String formatDateForJsp(Date d){
        SimpleDateFormat fobj = new SimpleDateFormat("MM/d/yyyy HH:mm");
        return fobj.format(d);
    }
    public static String date2String(Date d){
        SimpleDateFormat fobj = new SimpleDateFormat("MM/dd/yyyy");
        return fobj.format(d);
    }
    public static String date2String(Date d,String dateFormat){
        SimpleDateFormat fobj = new SimpleDateFormat(dateFormat);
        return fobj.format(d);
    }
    public static Date parseDate(String date, String format){        
        SimpleDateFormat fobj = new SimpleDateFormat(format);
        try{
            return fobj.parse(date);
        }catch(Exception ex){
            return null;
        }
    }
    
}
