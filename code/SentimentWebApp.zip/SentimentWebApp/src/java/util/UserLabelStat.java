/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

/**
 *
 * @author Mamoun.Awad
 */
public class UserLabelStat {
   private String userId;
   private int count;
   private String corp;
   public UserLabelStat(){}
   public UserLabelStat(String userId, String corp, long count){
       this.userId = userId;
       this.corp = corp;
       this.count = (int)count;
   }
   public UserLabelStat(String id, long count){
       this(id,"All",(int)count);
   }
   public String getUserId(){ return this.userId;}
   public int getCount(){ return this.count;}
   public String getCorp(){ return this.corp;}
   
    @Override
    public String toString() {
        return "UserLabelStat{" + "userId=" + userId + ", count=" + count + ", corp=" + corp + '}';
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public void setCorp(String corp) {
        this.corp = corp;
    }
   
   
}
