/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;
import java.io.Serializable;
import java.util.List;
import managers.TwitterT;
/**
 *
 * @author Mamoun.Awad
 */
public class TweetDetails implements Serializable{
    public static final long serialVersionUID = 42L;
    TwitterT tweetObj;
    int mSentiment;
    int hSentiment;
    String corp;
    public TweetDetails(TwitterT obj, int mSentiment){
        this.tweetObj = obj;
        this.mSentiment = mSentiment;
    }
    public TweetDetails(TwitterT obj, int mSentiment, int hSentiment){
        this(obj,mSentiment);
        this.hSentiment = hSentiment;
    }
    public TweetDetails(TwitterT obj, int mSentiment, int hSentiment, String corp){
        this(obj,mSentiment,hSentiment);
        this.corp = corp;
    }

    public TwitterT getTweetObj() {
        return tweetObj;
    }

    public int getmSentiment() {
        return mSentiment;
    }

    public void setTweetObj(TwitterT tweetObj) {
        this.tweetObj = tweetObj;
    }

    public void setmSentiment(int mSentiment) {
        this.mSentiment = mSentiment;
    }

    public void sethSentiment(int hSentiment) {
        this.hSentiment = hSentiment;
    }

    public void setCorp(String corp) {
        this.corp = corp;
    }

    public int gethSentiment() {
        return hSentiment;
    }

    public String getCorp() {
        return corp;
    }

    @Override
    public String toString() {
        return "TweetDetails{" + "tweetObj=" + tweetObj + ", mSentiment=" + mSentiment + ", hSentiment=" + hSentiment + ", corp=" + corp + '}';
    }
    public String getExcelFormat(){
        return tweetObj.getTweetId() +"\t"  + 
               tweetObj.getTwText().replace('\t', ' ') + "\t" +
               tweetObj.getTwUser() +"\t" + 
               tweetObj.getTwLocation() + "\t" + 
               tweetObj.getTwLang() + "\t" + 
               managers.Util.getSentimentStr(mSentiment) + "\t" + 
               managers.Util.getSentimentStr(hSentiment) + "\t" + 
               corp ;
    }
    public static String getExcelHeader(){
        return "TweetId\t"  + 
               "Text\t" +
               "User\t" + 
               "Location\t" + 
               "Language\t" + 
               "Machine Sentiment\t" + 
               "Human Sentiment\t" + 
               "Corp" ;
    }
    public static String tweets2Excel(List<TweetDetails> lst){
        StringBuffer sb = new StringBuffer(1024 * 10);
        sb.append(getExcelHeader()).append("\n");
        for(TweetDetails t : lst){
            sb.append(t.getExcelFormat()).append("\n");
        }
        return sb.toString();
    }
    
}
