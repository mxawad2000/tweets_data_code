/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

public class Account implements java.io.Serializable {
    public static final int USER_ROLE = 1;
    public static final int ADMIN_ROLE = 0;
    private static final long serialVersionUID = 1L;
    private String userID; //login user
    private String email; //email 
    private String fname,lname;
    private int role;
    public Account() {
    }

    public Account(String id, String email, int role) {
        this.userID = id;
        this.email = email;
        this.role = role;
    }

    public String getFirstName() {
        return fname;
    }
    public String getLastName(){ return lname;}

    public void setName(String fname, String lname) {
        this.fname = fname; this.lname = lname;
    }
    
    public String getEmail() {
        return this.email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setLoginID(String id) {
        this.userID = id;
    }

    public String getLoginID() {
        return userID;
    }

    public int getRole() {
        return this.role;
    }

    public void setRole(int role) {
        this.role = role;
    }

    public boolean isAdmin() {
        return role == Account.ADMIN_ROLE;
    }

    
    public boolean isRegularUser() {
        return role == Account.USER_ROLE;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (obj instanceof String) {
            String id = (String) obj;
            return this.userID.equals(id);
        } else if (obj instanceof Account) {
            Account ac = (Account) obj;
            return this.userID.equals(ac.userID);
        }
        return false;
    }
}



