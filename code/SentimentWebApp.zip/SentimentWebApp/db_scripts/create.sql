##To run this script type in:
##\. name_of_this_file_with_complete_path
delimiter ;
DROP DATABASE sentiments;
CREATE DATABASE sentiments;
USE sentiments;

show warnings \G
#role: 0 admin, user 1
CREATE TABLE user_t(
	user_id VARCHAR(20),
	password VARCHAR(32) not null,
        fname VARCHAR(20),
        lname VARCHAR(20),
        role VARCHAR(1) DEFAULT '1',
        email VARCHAR(100),
        creation_date timestamp,
        Primary Key(user_id)
);
###############################################################################
INSERT INTO user_t (user_id,fname,lname, password, role,email) 
       VALUES ("admin" ,"admin","admin", "@dmin",'0',"mamoun.awad@uaeu.ac.ae");
INSERT INTO user_t (user_id,fname,lname, password, role,email) 
       VALUES ("user" ,"User","User", "User",'1',"mamoun.awad@uaeu.ac.ae");
update USER_T set password = md5(concat(user_id,'.', password ));
###############################################################################
#0=very negative, 1=Negatiive, 2=Neutral, 3=Positive, 4 very positive, 5 advertisement, 6=others.
#m_sentiment: machine sentiment:0, 1, 2, 3, 4, 5, 6=advertiment.
#h_sentiment: human/manual sentiments: -1 missing
CREATE TABLE TWITTER_T(
	tweet_id VARCHAR(30),        
	tw_user VARCHAR(32) not null,
        tw_date date,
        tw_text VARCHAR(400),
        tw_lang VARCHAR(30),
        tw_location VARCHAR(30),
        PRIMARY KEY (tweet_id)
);
###############################################################################
CREATE TABLE SENTIMENT_T(
	tweet_id VARCHAR(30) NOT NULL ,        
        corp VARCHAR(30) NOT NULL,
        m_sentiment INT NOT NULL DEFAULT 2,
        h_sentiment INT NOT NULL DEFAULT -1,
        PRIMARY KEY (tweet_id, corp)  ,
        FOREIGN KEY (tweet_id) REFERENCES TWITTER_T (tweet_id)
      
);
################################################################################
CREATE TABLE Label_User_T(
	tweet_id VARCHAR(30) NOT NULL ,        
        corp VARCHAR(30) NOT NULL,
        user_id VARCHAR(20) NOT NULL,
        FOREIGN KEY (tweet_id) REFERENCES TWITTER_T(tweet_id),
        FOREIGN KEY (user_id)  REFERENCES USER_T (user_id)      
);
################################################################################